function load(url) {
    return new Promise(function (resolve, reject) {
/*XMLHttpRequest is a built-in browser object that allows to make HTTP requests in JavaScript.
            The XMLHttpRequest object is a developers dream, because you can:
                    1) Update a web page without reloading the page
                    2) Request data from a server - after the page has loaded
                    3) Receive data from a server  - after the page has loaded
                    4) Send data to a server - in the background
            */
        const request = new XMLHttpRequest();
        /** The XMLHttpRequest.onreadystatechange property contains the event handler to be 
         * called when the readystatechange event is fired, that is every time the readyState 
         * property of the XMLHttpRequest changes. */
        request.onreadystatechange = function (e) {
            if (this.readyState === 4) {
                if (this.status == 200) {
                    resolve(this.response);
                } else {
                    reject(this.status);
                }
            }
        }
        request.open('GET', url, true);
        request.send();
    });
}

const btn = document.querySelector('#btnGet');
const msg = document.querySelector('#message');
btn.onclick = function () {
    load('https://api.coindesk.com/v1/bpi/currentprice.json')
        .then(
            response => {
                const result = JSON.parse(response);
                msg.innerHTML = result.time.updated;
            },
            error => msg.innerHTML = `Error getting the message, HTTP status: ${error}`
        );
}
